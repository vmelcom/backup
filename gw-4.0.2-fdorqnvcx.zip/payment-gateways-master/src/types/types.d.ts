declare module 'paytmchecksum';
declare module 'paystack-node';
