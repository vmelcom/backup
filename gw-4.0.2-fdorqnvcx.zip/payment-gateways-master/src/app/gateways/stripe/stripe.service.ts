import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Stripe } from 'stripe';
import { Repository } from 'typeorm';
import { GatewayToUserEntity } from '../../database/gateway-to-user.entity';
import { PaymentGatewayEntity } from '../../database/payment-gateway.entity';
import { PaymentLinkResult } from '../paypal/paypal.service';
import { IntentResult } from '@ridy/database';
import { PayoutMethodEntity } from '../../database/payout-method.entity';

@Injectable()
export class StripeService {
  constructor(
    @InjectRepository(GatewayToUserEntity)
    private gatewayToUserRepo: Repository<GatewayToUserEntity>,
  ) {}

  async createPaymentLink(input: {
    gatewayId: number;
    userType: string;
    userId: string;
    privateKey: string;
    currency: string;
    amount: string;
    shouldPreauth: boolean;
  }): Promise<PaymentLinkResult> {
    const internalUserId = `${input.userType}_${input.userId}`;
    const transactionId = `${internalUserId}_${new Date().getTime()}`;
    const instance = new Stripe(input.privateKey, {
      apiVersion: '2022-11-15',
    });
    const externalCustomerId = await this.getCustomerId({
      paymentGatewayId: input.gatewayId.toString(),
      paymentGatewayPrivateKey: input.privateKey,
      userId: input.userId,
      userType: input.userType,
    });
    const intent = await instance.checkout.sessions.create({
      customer: externalCustomerId,
      line_items: [
        {
          price_data: {
            currency: input.currency,
            product_data: {
              name: 'Add funds',
            },
            unit_amount: Math.ceil(parseFloat(input.amount) * 100),
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${process.env.GATEWAY_SERVER_URL}/stripe/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.GATEWAY_SERVER_URL}/stripe/cancel?session_id={CHECKOUT_SESSION_ID}`,
      payment_intent_data: {
        setup_future_usage: 'off_session',
        capture_method: input.shouldPreauth ? 'manual' : 'automatic',
      },
    });
    return {
      invoiceId: transactionId,
      url: intent.url!,
      externalReferenceNumber: intent.id,
    };
  }

  async getCustomerId(input: {
    paymentGatewayId: string;
    paymentGatewayPrivateKey: string;
    userType: string;
    userId: string;
  }): Promise<string> {
    const internalUserId = `${input.userType}_${input.userId}`;
    const gatewayToUserEntity = await this.gatewayToUserRepo.findOneBy({
      internalUserId: internalUserId,
    });
    if (gatewayToUserEntity == null) {
      const newCustomer = await this.createCustomer({
        apiKey: input.paymentGatewayPrivateKey,
        userType: input.userType,
        userId: input.userId,
      });
      await this.gatewayToUserRepo.insert({
        internalUserId,
        externalReferenceNumber: newCustomer.id,
        gatewayId: parseInt(input.paymentGatewayId),
      });
      return newCustomer.id;
    } else {
      return gatewayToUserEntity.externalReferenceNumber;
    }
  }

  async setupSavedMethod(input: {
    paymentGatewayId: string;
    paymentGatewayPrivateKey: string;
    userType: string;
    userId: string;
    currency: string;
  }): Promise<PaymentLinkResult> {
    const instance = new Stripe(input.paymentGatewayPrivateKey, {
      apiVersion: '2022-11-15',
    });
    const customerId = await this.getCustomerId({
      ...input,
    });
    const internalUserId = `${input.userType}_${input.userId}`;
    const transactionId = `${internalUserId}_${new Date().getTime()}`;
    const intent = await instance.checkout.sessions.create({
      customer: customerId,
      mode: 'setup',
      currency: input.currency,
      metadata: {
        userId: input.userId,
        userType: input.userType,
        gatewayId: input.paymentGatewayId,
      },
      success_url: `${process.env.GATEWAY_SERVER_URL}/stripe/success_attach?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.GATEWAY_SERVER_URL}/stripe/cancel_attach?session_id={CHECKOUT_SESSION_ID}`,
    });
    Logger.log(intent, 'setupSavedMethod');
    return {
      url: intent.url!,
      invoiceId: transactionId,
      externalReferenceNumber: intent.id,
    };
  }

  async chargeSavedPaymentMethod(input: {
    gatewayPrivateKey: string;
    token: string;
    customerId: string;
    currency: string;
    amount: number;
  }): Promise<IntentResult & { transactionNumber: string }> {
    const instance = new Stripe(input.gatewayPrivateKey, {
      apiVersion: '2022-11-15',
    });

    Logger.log(input, 'chargeSavedPaymentMethod input');

    const paymentIntent = await instance.paymentIntents.create({
      payment_method: input.token,
      customer: input.customerId,
      currency: input.currency,
      amount: Math.ceil(input.amount * 100),
      confirm: true,
    });

    Logger.log(paymentIntent, 'chargeSavedPaymentMethod.paymentIntent');

    if (paymentIntent.status == 'requires_action') {
      const result: IntentResult & { transactionNumber: string } = {
        status: 'redirect',
        transactionNumber: paymentIntent.id,
        url: paymentIntent.next_action!.redirect_to_url!.url!,
      };
      Logger.log(result, 'chargeSavedPaymentMethod.requires_action.result');
      return result;
    } else if (paymentIntent.status == 'succeeded') {
      const result: IntentResult & { transactionNumber: string } = {
        transactionNumber: paymentIntent.id,
        status: 'success',
      };
      Logger.log(result, 'chargeSavedPaymentMethod.succeeded.result');
      return result;
    } else {
      Logger.log(
        paymentIntent.status,
        'chargeSavedPaymentMethod.unknown.status',
      );
      throw new Error('Unknown payment intent status');
    }
  }

  async getSession(
    gateway: PaymentGatewayEntity,
    sessionId: string,
  ): Promise<Stripe.Checkout.Session> {
    const instance = new Stripe(gateway.privateKey!, {
      apiVersion: '2022-11-15',
    });
    const session = await instance.checkout.sessions.retrieve(sessionId);
    return session;
  }

  async getSetupIntentPaymentMethodDetails(
    gateway: PaymentGatewayEntity,
    intentToken: string,
  ): Promise<Stripe.PaymentMethod> {
    const instance = new Stripe(gateway.privateKey!, {
      apiVersion: '2022-11-15',
    });
    const intent = await instance.setupIntents.retrieve(intentToken, {
      expand: ['payment_method'],
    });
    return intent.payment_method as Stripe.PaymentMethod;
  }

  private async createCustomer(input: {
    apiKey: string;
    userType: string;
    userId: string;
  }): Promise<Stripe.Response<Stripe.Customer>> {
    const instance = new Stripe(input.apiKey, {
      apiVersion: '2022-11-15',
    });
    const customer = await instance.customers.create({
      name: `${input.userType}_${input.userId}`,
    });
    return customer;
  }

  async capturePayment(input: {
    gateway: PaymentGatewayEntity;
    transactionNumber: string;
    amount: number;
  }): Promise<IntentResult> {
    const instance = new Stripe(input.gateway.privateKey!, {
      apiVersion: '2022-11-15',
    });
    const session = await instance.checkout.sessions.retrieve(
      input.transactionNumber,
    );
    const captureResult = await instance.paymentIntents.capture(
      session.payment_intent as unknown as string,
      {
        amount_to_capture: Math.ceil(input.amount * 100),
      },
    );
    const result = this.handlePaymentIntentStatus(captureResult);
    return result;
  }

  handlePaymentIntentStatus(paymentIntent: Stripe.PaymentIntent): IntentResult {
    if (paymentIntent.status == 'requires_action') {
      if (paymentIntent.next_action?.redirect_to_url) {
        return {
          status: 'redirect',
          url: paymentIntent.next_action.redirect_to_url.url!,
        };
      } else {
        throw new Error('Unknown next action');
      }
    } else if (paymentIntent.status == 'succeeded') {
      return {
        status: 'success',
      };
    } else {
      throw new Error('Unknown payment intent status');
    }
  }

  async cancelPreauth(input: {
    gateway: PaymentGatewayEntity;
    transactionNumber: string;
  }): Promise<IntentResult> {
    const instance = new Stripe(input.gateway.privateKey!, {
      apiVersion: '2022-11-15',
    });
    const session = await instance.checkout.sessions.retrieve(
      input.transactionNumber,
    );
    const captureResult = await instance.paymentIntents.cancel(
      session.payment_intent as unknown as string,
    );
    const result = this.handlePaymentIntentStatus(captureResult);
    return result;
  }

  // async getPaymentLink(
  //   userType: string,
  //   userId: string,
  //   merchantId: string,
  //   privateKey: string,
  //   currency: string,
  //   amount: string
  // ): Promise<PaymentLinkResult> {
  //   const internalUserId = `${userType}_${userId}`;
  //   const transactionId = `${internalUserId}_${new Date().getTime()}`;
  //   const instance = new Stripe(privateKey, { apiVersion: '2022-11-15' });
  //   const session = await instance.checkout.sessions.create({
  //     payment_method_types: ['card'],
  //     line_items: [
  //       {
  //         price_data: {
  //           currency: currency,
  //           product_data: {
  //             name: 'Top-up wallet',
  //           },
  //           unit_amount: Math.round(parseFloat(amount)) * 100,
  //         },
  //         quantity: 1,
  //       },
  //     ],
  //     mode: 'payment',
  //     success_url: `${process.env.GATEWAY_SERVER_URL}/stripe/success?transactionId=${transactionId}`,
  //     cancel_url: `${process.env.GATEWAY_SERVER_URL}/stripe/cancel?transactionId=${transactionId}`,
  //   });
  //   return {
  //     invoiceId: transactionId,
  //     url: session.url!,
  //   };
  // }

  async getPayoutLinkUrl(input: {
    method: PayoutMethodEntity;
    userType: string;
    userId: number;
    returnUrl: string;
  }) {
    const instance = new Stripe(input.method.privateKey!, {
      apiVersion: '2022-11-15',
    });
    let account: Stripe.Account;
    try {
      account = await instance.accounts.retrieve(input.userId.toString());
    } catch (error) {
      account = await instance.accounts.create({
        type: 'express',
        capabilities: {
          transfers: {
            requested: true,
          },
        },
        metadata: {
          userId: input.userId.toString(),
          userType: input.userType,
          return_url: input.returnUrl,
        },
        business_type: 'individual',
        // individual: {
        //   first_name: 'john',
        //   last_name: 'doe',
        //   phone: '+16505551234',
        //   address: {
        //     line1: 'address_full_match',
        //     city: 'city_full_match',
        //     state: 'state_full_match',
        //     postal_code: 'postal_code_full_match',
        //   },

        //   dob: {
        //     day: 1,
        //     month: 1,
        //     year: 1901,
        //   },
        //   id_number: '000000000',
        //   verification: {
        //     document: {
        //       front: 'file_identity_document_success',
        //     },
        //   },
        // },
      });
    }
    Logger.log(account, 'stripeService.getPayoutLinkUrl.account');
    const link = await instance.accountLinks.create({
      account: account.id,
      refresh_url: `${process.env.GATEWAY_SERVER_URL}/stripe/payout/refresh`,
      return_url: `${process.env.GATEWAY_SERVER_URL}/stripe/payout/return?account_id=${account.id}&payout_method_id=${input.method.id}`,
      type: 'account_onboarding',
    });
    Logger.log(link, 'stripeService.getPayoutLinkUrl.link');
    return link.url;
  }

  async verify(
    paymentGateway: PaymentGatewayEntity,
    transactionNumber: string,
  ): Promise<Stripe.Checkout.Session> {
    const instance = new Stripe(paymentGateway.privateKey!, {
      apiVersion: '2022-11-15',
    });
    const response =
      await instance.checkout.sessions.retrieve(transactionNumber);
    return response;
  }
}
